"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseBrowser";

type Commission = {
  order_id: string;
  client_amount: number;
  driver_amount: number;
  restaurant_amount: number;
  platform_amount: number;
  currency: string;
  updated_at: string;
};

export default function CommissionSummary({ orderId }: { orderId: string }) {
  const [c, setC] = useState<Commission | null>(null);

  async function load() {
    const { data } = await supabase
      .from("order_commissions")
      .select("*")
      .eq("order_id", orderId)
      .maybeSingle();
    if (data) setC(data as Commission);
  }

  useEffect(() => {
    load();
    const ch = supabase
      .channel(`commission:${orderId}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "order_commissions", filter: `order_id=eq.${orderId}` }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [orderId]);

  if (!c) return <div className="text-gray-500">Pas de données de commission.</div>;
  const fmt = (n: number) => new Intl.NumberFormat(undefined, { style: "currency", currency: c.currency || "USD" }).format(n);

  return (
    <div className="rounded-xl border p-4 space-y-2">
      <div className="font-semibold">Commissions</div>
      <div>Client : {fmt(c.client_amount)}</div>
      <div>Driver : {fmt(c.driver_amount)}</div>
      <div>Restaurant : {fmt(c.restaurant_amount)}</div>
      <div>Plateforme : {fmt(c.platform_amount)}</div>
      <div className="text-xs text-gray-500">Maj : {new Date(c.updated_at).toLocaleString()}</div>
    </div>
  );
}
