"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { supabase } from "@/lib/supabaseBrowser";

type Row = {
  id: string;
  status: string | null;
  subtotal: number | null;
  currency: string | null;
  created_at: string;
  updated_at: string;
  my_role: string | null;
};

const STATUSES = ["pending","assigned","accepted","prepared","ready","dispatched","delivered"];

export default function OrdersList() {
  const [rows, setRows] = useState<Row[]>([]);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  async function load() {
    try {
      setLoading(true); setErr(null);
      let query = supabase.from("v_my_orders").select("*").order("created_at", { ascending: false });
      if (status) query = query.eq("status", status);
      const { data, error } = await query;
      if (error) throw error;
      setRows((data as Row[]) ?? []);
    } catch (e:any) {
      setErr(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { void load(); }, [status]);

  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase();
    if (!t) return rows;
    return rows.filter(r =>
      r.id.toLowerCase().includes(t) ||
      (r.status ?? "").toLowerCase().includes(t) ||
      (r.my_role ?? "").toLowerCase().includes(t)
    );
  }, [rows, q]);

  const fmtMoney = (n: number | null | undefined, ccy: string | null | undefined) =>
    new Intl.NumberFormat(undefined, { style: "currency", currency: ccy || "USD" })
      .format(Number.isFinite(Number(n)) ? Number(n) : 0);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2 items-end">
        <div className="flex-1 min-w-[220px]">
          <label className="block text-xs text-gray-600 mb-1">Rechercher (id, statut, rôle)</label>
          <input
            value={q}
            onChange={e=>setQ(e.target.value)}
            placeholder="a80cf7e1, delivered, driver…"
            className="w-full border rounded px-3 py-2"
          />
        </div>
        <div>
          <label className="block text-xs text-gray-600 mb-1">Statut</label>
          <select value={status} onChange={e=>setStatus(e.target.value)} className="border rounded px-3 py-2">
            <option value="">Tous</option>
            {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        <button onClick={()=>{ setQ(""); setStatus(""); void load(); }} className="border rounded px-3 py-2">
          Réinitialiser
        </button>
      </div>

      {loading && <div className="text-sm text-gray-500">Chargement…</div>}
      {err && <div className="text-sm text-red-600">{err}</div>}

      {!loading && filtered.length === 0 && (
        <div className="text-sm text-gray-500">Aucune commande.</div>
      )}

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(r => (
          <div key={r.id} className="border rounded-2xl p-4 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="font-semibold">#{r.id.slice(0,8)}</div>
              <span className="text-xs uppercase tracking-wide">{r.status}</span>
            </div>
            <div className="text-sm text-gray-600 mt-1">
              Rôle: <span className="font-medium">{r.my_role ?? "member"}</span>
            </div>
            <div className="text-sm mt-2">
              Total: <span className="font-semibold">{fmtMoney(r.subtotal, r.currency)}</span>
            </div>
            <div className="text-[11px] text-gray-500 mt-1">
              Créée: {new Date(r.created_at).toLocaleString()}
            </div>
            <div className="mt-3 flex gap-2">
              <Link href={`/orders/${r.id}/chat`} className="text-sm px-3 py-1.5 border rounded hover:bg-gray-50">
                Ouvrir le chat
              </Link>
              <Link href={`/orders/${r.id}`} className="text-sm px-3 py-1.5 border rounded hover:bg-gray-50">
                Détails
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
