"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseBrowser";

type Row = {
  id: string;
  order_id: string;
  user_id: string;
  text: string | null;
  image_path: string | null;
  created_at: string;
};

export default function ChatMessages({ orderId }: { orderId: string }) {
  const [rows, setRows] = useState<Row[]>([]);
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  async function reload() {
    setErr(null); setLoading(true);
    const { data, error } = await supabase
      .from("order_messages")
      .select("*")
      .eq("order_id", orderId)
      .order("created_at", { ascending: true });
    setLoading(false);
    if (error) { setErr(error.message); return; }
    setRows((data || []) as Row[]);
  }

  async function del(id: string) {
    const keep = rows.filter(r => r.id !== id);
    setRows(keep);
    const { error } = await supabase.from("order_messages").delete().eq("id", id);
    if (error) { alert(error.message); reload(); }
  }

  useEffect(() => {
    reload();
    // Realtime: se réabonner aux inserts/delete de ce order_id
    const ch = supabase
      .channel(`chat:${orderId}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "order_messages", filter: `order_id=eq.${orderId}` }, () => reload())
      .on("postgres_changes", { event: "DELETE", schema: "public", table: "order_messages", filter: `order_id=eq.${orderId}` }, () => reload())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [orderId]);

  return (
    <div className="space-y-3">
      {err && <div className="text-red-600">Erreur: {err}</div>}
      {loading && <div className="text-gray-500">Chargement…</div>}
      {rows.length === 0 && !loading && <div className="text-gray-500">Aucun message pour le moment.</div>}
      {rows.map(m => {
        const url = m.image_path
          ? supabase.storage.from("chat-images").getPublicUrl(m.image_path).data.publicUrl
          : null;
        return (
          <div key={m.id} className="border rounded p-2">
            <div className="text-xs text-gray-500">{new Date(m.created_at).toLocaleString()}</div>
            {m.text && <div className="py-1 whitespace-pre-wrap">{m.text}</div>}
            {url && (
              <div className="py-1">
                <a href={url} target="_blank" rel="noreferrer" className="underline">Voir l’image</a>
              </div>
            )}
            <button onClick={() => del(m.id)} className="text-red-600 text-sm underline">supprimer</button>
          </div>
        );
      })}
    </div>
  );
}
