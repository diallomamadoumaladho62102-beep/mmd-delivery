import type { ReactNode } from 'react';
export const dynamic = 'force-dynamic';

export default function OrderIdLayout({ children }: { children: ReactNode }) {
  return <>{children}</>;
}
