"use client";

import { useEffect } from "react";
import { useParams } from "next/navigation";
import { supabase } from "@/lib/supabaseBrowser";
import ChatMessages from "@/components/ChatMessages";
import CommissionSummary from "@/components/CommissionSummary";
import ChatInput from "@/components/ChatInput";

export default function OrderChatPage() {
  const params = useParams<{ orderId: string }>();
  const orderId = params.orderId;

  useEffect(() => {
    (async () => {
      try { await supabase.rpc("refresh_order_commissions", { p_order_id: orderId }); } catch {}
    })();
  }, [orderId]);

  return (
    <div className="max-w-3xl mx-auto p-4 space-y-6">
      <h1 className="text-xl font-bold">Chat — commande #{orderId}</h1>
      <CommissionSummary orderId={orderId} />
      <ChatMessages orderId={orderId} />
      <ChatInput orderId={orderId} onSent={() => { /* rien, le realtime recharge */ }} />
    </div>
  );
}
