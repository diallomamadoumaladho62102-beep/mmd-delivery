"use client";
import { useParams } from "next/navigation";
import OrderDetails from "@/components/OrderDetails";

export default function OrderPage() {
  const params = useParams();
  const raw = (params as Record<string, string | string[] | undefined>)?.orderId;
  const orderId = Array.isArray(raw) ? (raw?.[0] ?? "") : (raw ?? "");
  if (!orderId) return <main className="p-6">Order ID manquant</main>;
  return <OrderDetails orderId={orderId} />;
}
