import OrdersList from "@/components/OrdersList";

export default function OrdersPage() {
  return (
    <main className="p-6 space-y-4">
      <div className="flex items-baseline gap-3">
        <h1 className="text-2xl font-bold">Mes commandes</h1>
      </div>
      <OrdersList />
    </main>
  );
}
