"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabaseBrowser";
import Link from "next/link";

export default function SignInPassword() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string|null>(null);

  async function signIn() {
    setErr(null);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setErr(error.message);
    else window.location.href = "/auth/whoami";
  }

  return (
    <div className="max-w-md mx-auto p-6 border rounded-xl mt-10 space-y-3">
      <h1 className="text-xl font-bold">Connexion (email + mot de passe)</h1>
      <input
        type="email"
        className="w-full border rounded px-3 py-2"
        placeholder="you@example.com"
        value={email}
        onChange={e=>setEmail(e.target.value)}
      />
      <input
        type="password"
        className="w-full border rounded px-3 py-2"
        placeholder="mot de passe"
        value={password}
        onChange={e=>setPassword(e.target.value)}
      />
      <button onClick={signIn} className="px-4 py-2 rounded bg-black text-white">
        Se connecter
      </button>
      {err && <p className="text-red-600">{err}</p>}
      <p className="text-sm text-gray-500">
        Ou <Link href="/auth/sign-in" className="underline">lien magique par email</Link>
      </p>
    </div>
  );
}
